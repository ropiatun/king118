 <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright @ <?php echo SITE_NAME ." ". Date ('Y') ?></span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->